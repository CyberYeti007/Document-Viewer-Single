import Uploader from "@/components/functional/file-uploader"

const UploadPage = () => {
    return (
        <Uploader />
    )
}

export default UploadPage;